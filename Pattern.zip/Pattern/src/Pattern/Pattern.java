package Pattern;
import java.util.Scanner;
public class Pattern {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);	
	String myString=sc.next();
	int half=myString.length()/2;
	String part1=myString.substring(0, half);
	char[] ch1=part1.toCharArray();
	String part2=myString.substring(half);
	char[] ch2=part2.toCharArray();
	sc.close();
    /****PATTERN****/
	int k=ch2.length-1;
	int m=ch1.length-1;
	for(int i=0;i<myString.length();i++)
	{
	if(i<ch2.length)
	{
	for(int j=0;j<ch2.length-k;j++)
	{
		
		System.out.print(ch2[j]);
	}
	k--;
	}
	else
	{
		for(int j=0;j<ch1.length-m;j++)
		{
			if(j==0)
				System.out.print(part2);
			System.out.print(ch1[j]);
		}
		m--;
	}
	System.out.println();
	}
	}

}
